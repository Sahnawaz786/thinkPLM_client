import React from 'react';

const SupplierSearch = () => {
  return (
    <div>SupplierSearch</div>
  )
}

export default SupplierSearch;