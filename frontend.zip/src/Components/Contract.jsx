import React from 'react'

const Contract = () => {
  return (
    <div>Contract</div>
  )
}

export default Contract