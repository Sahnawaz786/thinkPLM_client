import React from 'react'

const OnBoard = () => {
  return (
    <div>OnBoard</div>
  )
}

export default OnBoard